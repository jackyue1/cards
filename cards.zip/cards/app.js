document.addEventListener("DOMContentLoaded", function () {
  const apiUrl =
    "https://people.canonical.com/~anthonydillon/wp-json/wp/v2/posts";
  const cardContainer = document.getElementById("cardContainer");

  fetch(apiUrl)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      data.forEach((post) => {
        const card = createCard(post);
        cardContainer.appendChild(card);
      });
    })
    .catch((error) => {
      console.error("Fetch error:", error);
    });

  function createCard(post) {
    const card = document.createElement("div");
    card.classList.add("card");

    // Grouping
    const groupContainer = document.createElement("p");
    if (
      post._embedded &&
      post._embedded["wp:term"] &&
      post._embedded["wp:term"][2] &&
      post._embedded["wp:term"][2][0] &&
      post._embedded["wp:term"][2][0].name
    ) {
      groupContainer.textContent = ` ${post._embedded[
        "wp:term"
      ][2][0].name.toUpperCase()}`;
      card.appendChild(groupContainer);
    }

    // Light gray bar after grouping
    const groupBar = document.createElement("hr");
    groupBar.classList.add("light-gray-bar");
    card.appendChild(groupBar);

    // Featured image
    if (
      post.featured_media &&
      (typeof post.featured_media === "string" ||
        (post.featured_media[0] && post.featured_media[0].source_url))
    ) {
      const image = document.createElement("img");
      const sourceUrl =
        typeof post.featured_media === "string"
          ? post.featured_media
          : post.featured_media[0].source_url;

      image.src = sourceUrl;
      image.alt = post.title.rendered;

      // Apply max-width
      image.style.maxWidth = "100%";

      card.appendChild(image);
    } else {
      // Log a message if the condition is not met
      console.log("No featured image available");
    }

    // Title
    const title = document.createElement("h2");
    const titleLink = document.createElement("a");
    titleLink.textContent = post.title.rendered;
    titleLink.href = post.link; // Assuming 'link' is the property containing the article URL
    titleLink.style.color = "#66a3ff"; // Set hyperlink color to a lighter blue
    titleLink.style.textDecoration = "none"; // Remove underline
    title.appendChild(titleLink);
    card.appendChild(title);

    // Author and Date Container
    const authorDateContainer = document.createElement("div");

    // Author and Date
    const authorAndDate = document.createElement("p");

    // Author
    if (
      post._embedded &&
      post._embedded.author &&
      post._embedded.author[0] &&
      post._embedded.author[0].name
    ) {
      const authorLink = document.createElement("a");
      const byText = document.createElement("em");
      byText.textContent = "By ";
      byText.style.color = "#555555";
      authorLink.appendChild(byText);
      const authorName = document.createElement("em");
      authorName.textContent = post._embedded.author[0].name;
      authorName.style.color = "#66a3ff";
      authorLink.appendChild(authorName);
      authorLink.href = post._embedded.author[0].link;
      authorLink.style.textDecoration = "none";
      authorAndDate.appendChild(authorLink);

      const onText = document.createElement("span");
      onText.innerHTML = "<em> on </em>";
      authorAndDate.appendChild(onText);
    }

    // Date
    if (post.date) {
      const formattedDate = new Date(post.date)
        .toLocaleDateString("en-US", {
          day: "numeric",
          month: "long",
          year: "numeric",
        })
        .replace(/(\w+) (\d+), (\d+)/, "$2 $1 $3"); // Adjust the regular expression.

      const dateElement = document.createElement("em");
      dateElement.textContent = formattedDate;
      authorAndDate.appendChild(dateElement);
    }

    // Append the combined Author and Date to the container
    authorDateContainer.appendChild(authorAndDate);

    // Append the Author and Date Container to the card
    card.appendChild(authorDateContainer);

    // Light gray bar after the date
    const dateBar = document.createElement("hr");
    dateBar.classList.add("light-gray-bar");
    card.appendChild(dateBar);

    // Group name
    const groupName = document.createElement("p");
    if (
      post._embedded &&
      post._embedded["wp:term"] &&
      post._embedded["wp:term"][0] &&
      post._embedded["wp:term"][0][0] &&
      post._embedded["wp:term"][0][0].name
    ) {
      groupName.textContent = ` ${post._embedded["wp:term"][0][0].name}`;
      card.appendChild(groupName);
    }

    return card;
  }
});
